# CAB System – API Documentation (OpenAPI 3.0.3)

Tài liệu API được tách thành nhiều file YAML nhỏ, **mỗi nhóm chức năng (FR) là một file**,
bám theo tài liệu phân tích nghiệp vụ trong `README.md` của đồ án.

## Cấu trúc thư mục

```text
api/
├── openapi.yaml                  # File gốc: info, servers, tags, security, danh sách paths
├── paths/                        # Mỗi Functional Requirement = 1 file
│   ├── fr01-auth.yaml            # FR01 – Đăng ký, đăng nhập, xác thực (UC01, UC02)
│   ├── fr02-customers.yaml       # FR02 – Hồ sơ khách hàng, lịch sử chuyến đi
│   ├── fr03-drivers.yaml         # FR03 – Tài xế, phương tiện, trạng thái sẵn sàng
│   ├── fr04-bookings.yaml        # FR04 – Đặt xe, theo dõi và hủy yêu cầu (UC03)
│   ├── fr05-matching.yaml        # FR05 – Tìm và phân công tài xế (UC04)
│   ├── fr06-trips.yaml           # FR06 – Trạng thái chuyến, theo dõi chuyến (UC05, UC08)
│   ├── fr07-payments.yaml        # FR07 – Tính cước và thanh toán (UC06, UC07)
│   ├── fr08-notifications.yaml   # FR08 – Thông báo
│   ├── fr09-ratings.yaml         # FR09 – Đánh giá tài xế
│   ├── fr10-operations.yaml      # FR10 – Quản lý vận hành, xử lý sự cố (UC09)
│   ├── fr11-reports.yaml         # FR11 – Báo cáo
│   ├── fr12-security.yaml        # FR12 – Phân quyền, audit log
│   └── fr13-locations.yaml       # FR13 – Vị trí tài xế, tìm tài xế gần, ETA
└── components/                   # Thành phần dùng lại
    ├── security-schemes.yaml     # bearerAuth (JWT), providerSignature (webhook)
    ├── parameters.yaml           # page, size, from, to
    ├── responses.yaml            # 400/401/403/404/409/422/503
    ├── schemas-common.yaml       # Error, PageMeta, Location, Money
    ├── schemas-user.yaml         # User, Customer, Driver, Vehicle, Role, AuditLog
    ├── schemas-booking.yaml      # Booking, MatchingState, DriverOffer
    ├── schemas-trip.yaml         # Trip, TripStatus, Rating, ETA, vị trí
    ├── schemas-payment.yaml      # Fare, Payment, ProviderWebhook
    └── schemas-ops.yaml          # Notification, Incident, các báo cáo
```

## Cách dùng

```bash
# Kiểm tra lỗi cú pháp và $ref
npx @redocly/cli lint openapi.yaml

# Gộp thành 1 file duy nhất để import vào Swagger UI / Postman
npx @redocly/cli bundle openapi.yaml -o cab-system.bundled.yaml

# Xem tài liệu dạng web
npx @redocly/cli preview-docs openapi.yaml
```

> Swagger Editor online không đọc được `$ref` sang file khác — hãy bundle trước rồi mở file
> `cab-system.bundled.yaml`.

## Truy vết Business Rules

Các Business Rule trong README được ghi chú trực tiếp trong phần `description` của endpoint:

| Business Rule | Thể hiện trong API |
|---|---|
| BR-01 Xác thực | `security: bearerAuth`, response `401` |
| BR-02 Phân quyền | response `403`, `fr12-security.yaml` |
| BR-03 Tài xế sẵn sàng | `PUT /drivers/{id}/availability` |
| BR-06, BR-07 Từ chối / không phản hồi | `POST /driver-offers/{id}/reject`, `expiresAt` |
| BR-08 Không tìm được tài xế | `BookingStatus = NO_DRIVER` |
| BR-10 Thứ tự trạng thái | `PUT /trips/{id}/status`, response `409` |
| BR-11 Tính cước | `POST /trips/{id}/fare` (chỉ khi `COMPLETED`) |
| BR-13 Dữ liệu thanh toán | chỉ nhận `providerToken`, không lưu số thẻ |
| BR-14 Thanh toán thất bại | `POST /payments/{id}/retry` |
| BR-16 Đánh giá | `POST /trips/{id}/rating` sau khi hoàn thành |
| BR-19 Audit log | `GET /audit-logs` |
| BR-20 Phân tách lỗi | response `503` cho dịch vụ bên ngoài |

Các quy tắc **chưa chốt** (BR-21 → BR-30: công thức tính cước, tiêu chí ưu tiên tài xế,
thời gian phản hồi, bán kính tìm kiếm, chính sách hủy…) được đánh dấu trong `description`
của các trường liên quan (`searchRadiusKm`, `expiresAt`, `Fare`, hủy chuyến) để BA xác nhận
với stakeholder trước khi hiện thực.
